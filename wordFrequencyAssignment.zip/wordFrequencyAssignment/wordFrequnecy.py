"""
This assignment loads a text file and do some data analysis on its content. We are
going to open a book file 'illiad.txt' which is already given. Then read all its 
content. After cleaning up the file's content, the goal is to find n most frequent
words in this book. Complete
the missing parts bellow. The missing parts are specified by ***Your code here*** lines.
"""

def ByFrequency(pair):
    return pair[1]

def main():
    '''This program analyzes word frequency in a file and prints a report on n most common words
    in the book.'''
    print("This program analyzes word frequency in a file and prints a report on n most common ")
    print("words in the book.\n")

    #get the file name from user:
    fname = input("File to process: ")
    try:
        content = None
        """Your code here"""
        """Ask user for filename to open for read. Then read its content fully.
           Then turn all characters to lower case user lower() method on string."""
        

        #replace all 'extra, non word, characters with space
        nonWordCharacters = '!"#$%()*+,-./:;<=>?@[\\]^_`{|}~'
        """Your code here. Replace any of the above characters in 'content' with ' '. """
        

        # create a dictionary of words' count, which is the number of times a word occurres in the book
        # like this: wordDictionary = {'book':120, ...}
        # Only consider words w which have more than 2 characters.
        wordDictionary = {}
        words = content.split()
        """Your code here"""

        # sort wordDictionary based on its words' count. Make sure to use sort() function
        # with proper key sorting function, as we did in class bellow. This means
        # after sorting the content of the dictionary is like this: ('the', 4321), ('is', 3211), ....
        """Your code here"""

        # ask user how many word top frequencies like to see:
        n = int(input("how many word top frequencies like to see?"))
        for i in range(n):
            word, count = pairItems[i]
            print("{0:<15} {1:>6}".format(word, count))
            
        # Now count how many sentences are in this book. A sentence always ends with a dot
        # like this: 'This is a sentence.' Use this info to count the number of sentences
        # in book and print it out:
        numOfSentences = 0
        """YOur code here"""
        print("Number of sentences is ", numOfSentences)

    except ValueError:
        print("ValueError exception happened!\n")
    except FileNotFoundError:
        print("File not found exception happened!\n")



if __name__ == '__main__':
    main()

